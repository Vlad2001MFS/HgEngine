b2dJson
=======

Utilities to load scenes created by the R.U.B.E Box2D editor.

Main info page is at: http://www.iforce2d.net/b2djson

Please also see the usage examples here: http://www.iforce2d.net/rube/?panel=loaders
